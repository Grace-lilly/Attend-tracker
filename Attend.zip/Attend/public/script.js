document.addEventListener('DOMContentLoaded', (event) => {
    const subjectHeader = document.getElementById('subject-header');

    subjectHeader.addEventListener('blur', () => {
        const updatedSubject = subjectHeader.innerText;
        // Send the updated subject to the server
        fetch('/api/update-subject', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${sessionStorage.getItem('token')}`
            },
            body: JSON.stringify({ subject: updatedSubject })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Success:', data);
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    });
});
