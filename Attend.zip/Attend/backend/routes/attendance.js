const express = require('express');
const router = express.Router();
const db = require('../db');

// ...existing code...

router.post('/add', (req, res) => {
    const { studentId, date, status, subject } = req.body;
    const query = 'INSERT INTO attendance (student_id, date, status, subject) VALUES (?, ?, ?, ?)';
    db.run(query, [studentId, date, status, subject], function(err) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ id: this.lastID });
    });
});

// ...existing code...

module.exports = router;
