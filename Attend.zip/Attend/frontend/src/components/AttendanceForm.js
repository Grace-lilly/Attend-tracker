import React, { useState } from 'react';
import axios from 'axios';

// ...existing code...

const AttendanceForm = () => {
    const [studentId, setStudentId] = useState('');
    const [date, setDate] = useState('');
    const [status, setStatus] = useState('');
    const [subject, setSubject] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        const attendanceData = { studentId, date, status, subject };
        axios.post('/api/attendance/add', attendanceData)
            .then(response => {
                console.log('Attendance saved:', response.data);
            })
            .catch(error => {
                console.error('There was an error saving the attendance!', error);
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            {/* ...existing code... */}
            <div>
                <label>Subject:</label>
                <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                />
            </div>
            {/* ...existing code... */}
        </form>
    );
};

export default AttendanceForm;
